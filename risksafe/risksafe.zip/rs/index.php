<?php

header("Location: view/main.php");

?>