<?php

include_once("../controller/auth.php");
include_once("../config.php");
include_once('../model/applicable.php');
$db = new db();
$conn = $db->connect();
if (isset($_REQUEST["response"]) and $_REQUEST["response"]=="true") {
	$msg="applicable saved successfully.";
}

if (isset($_REQUEST["response"]) and $_REQUEST["response"]=="err") {
	$msg="Error saving applicable, please try again.";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once("header.php");?>
</head>
<body>
<!-- header -->
<div id="top-nav" class="navbar navbar-inverse navbar-static-top" style="background-color:#09F;border:0;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand" href="main.php" style="font-weight:900;color:#fff;"><?php echo APP_TITLE;?></a> </div>
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown"> <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#" style="font-weight:900;color:#fff;"><i class="glyphicon glyphicon-user"></i> Account <span class="caret"></span></a>
          <ul id="g-account-menu" class="dropdown-menu" role="menu">
			<?php include_once("menu_top.php");?>
          </ul>
        </li>
      </ul>
    </div>
  </div>
  <!-- /container --> 
</div>
<!-- /Header --> 

<!-- Main -->
<div class="container-fluid">
<div class="row">
  <div class="col-lg-3 col-sm-12"> 
    <!-- Left column --> 
	<?php include_once("menu.php");?>
  <!-- /col-3 -->
  </div>
  <div class="col-lg-9 col-md-12">
    <h1 class="page-header"></h1>
  <div class="col-lg-9 col-md-12">
    <div class="panel panel-default">
      <div class="panel-body">
      <form action="" method="POST">
  <label for="category">Category:</label>
  <select name="category"  class="form-control"  id="category">
    <option value="">Select Category</option>
    <?php
    $query = "SELECT * FROM aml_categories";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
      echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
    }
    ?>
  </select>
  
  <label for="subcategory">Subcategory:</label>
  <select name="subcategory"  class="form-control"  id="subcategory">
    <option value="">Select Subcategory</option>
  </select>

  <div id="subcategory-fields" style="display: block;">
    <h3>Financial Risk Assessment Form</h3>
    <div class="form-group">
    <label for="company">Company Name:</label>
    <input type="text" class="form-control"  name="company" id="company" required>
  </div>
  <div class="form-group">
    <label for="risk_description">Risk Description:</label>
    <textarea name="risk_description" class="form-control"  id="risk_description" rows="4" required></textarea>
  </div>
  <div class="form-group">
    <label for="risk_level">Risk Level:</label>
    <select name="risk_level" class="form-control" id="risk_level">
      <option value="">Select Risk Level</option>
      <option value="Low">Low</option>
      <option value="Medium">Medium</option>
      <option value="High">High</option>
    </select>
  </div>
  <div class="form-group">
    <label for="controls">Risk Controls:</label>
    <textarea name="controls" class="form-control" id="controls" rows="4"></textarea>
  </div>
    <input type="submit" value="Submit">
  </div>



</form>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
  $('#category').change(function() {
    var categoryId = $(this).val();
    var subcategoryDropdown = $('#subcategory');
    
    // Clear existing options
    subcategoryDropdown.empty();
    subcategoryDropdown.append('<option value="">Select Subcategory</option>');
    
    if (categoryId !== '') {
      // Make AJAX request to retrieve related subcategories
      $.ajax({
        url: 'get_subcategories.php',
        method: 'POST',
        data: { categoryId: categoryId },
        dataType: 'html',
        success: function(response) {
          // Populate subcategory dropdown with retrieved data
          subcategoryDropdown.html(response);
        }
      });
    }
  });
});
</script>




      </div>
    </div>
  </div>
  </div>
  <!--/col-span-9--> 
</div>  
</div>

<!-- /Main -->

<?php include_once("footer.php");?>
<script>
$(document).ready(function(e) {
 
	$(function() {
		$("#start, #due").datepicker();
	});
	
	
	$("#btn_cancel").click(function(e) {
		$(location).attr("href","applicables.php");
    });
	
	$("#existing").change(function(e){
		
    	if ($("#existing").val()=="-1") {
			$("#treatment").val('');
			$("#team").val('');
			$("#assessor").val('');
		} else {
			
			$.ajax({
			  method: "POST",
			  url: "../controller/treatment.php?action=gettreatmentinfo&id="+$("#existing").val(),
			  async: false
			})
			  .done(function( msg ) {
				arr=JSON.parse(msg);
				$("#treatment").val(arr.treatment);
				$("#team").val(arr.team);
				$("#assessor").val(arr.assessor)
			  });
		}
    });
    
}); 
  </script>
</script>
</body>
</html>